package com.example.consumingrest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

@Service
public class HistoryService {
    @Autowired
    RestTemplate restTemplate;

   public Root getRoot(){
       return restTemplate.getForObject("https://today-in-history.p.rapidapi.com/thisday", Root.class);
   }
}
